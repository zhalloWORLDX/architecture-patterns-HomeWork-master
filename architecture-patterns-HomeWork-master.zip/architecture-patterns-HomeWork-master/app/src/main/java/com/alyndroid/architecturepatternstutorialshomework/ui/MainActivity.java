package com.alyndroid.architecturepatternstutorialshomework.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import com.alyndroid.architecturepatternstutorialshomework.R;
import com.alyndroid.architecturepatternstutorialshomework.pojo.NumberModel;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,ArchitectureInterFace {
    Button buttonplus;
    TextView Plus_result_textView;
    @BindView(R.id.plus_button)
    Button plusButton;
    @BindView(R.id.mul_button)
    Button mulButton;
    @BindView(R.id.div_button)
    Button divButton;
    @BindView(R.id.mul_result_textView)
    TextView mulResultTextView;
    @BindView(R.id.plus_result_textView)
    TextView plusResultTextView;
    @BindView(R.id.div_result_textView)
    TextView divResultTextView;
    @BindView(R.id.textView4)
    TextView textView4;
    @BindView(R.id.textView5)
    TextView textView5;
    architecturePresenter presenter;
    ArchitectureInterViewModel architectureInterViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        //view mvc
        buttonplus = findViewById(R.id.plus_button);
        Plus_result_textView = findViewById(R.id.plus_result_textView);
        buttonplus.setOnClickListener(this);
        //view MVP
        divButton.setOnClickListener(this);
        presenter = new architecturePresenter(this);

        //view mvvm
        mulButton.setOnClickListener(this);
        architectureInterViewModel = ViewModelProviders.of(this).get(ArchitectureInterViewModel.class);
        architectureInterViewModel.mutableLiveData.observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer integer) {
                mulResultTextView.setText(String.valueOf(integer));
            }
        });
    }

    //MVC
    public NumberModel getNumbers() {
        return new NumberModel(4, 2);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            //button mvc
            case  R.id.plus_button:
            getNumbers();
            Plus_result_textView.setText(String.valueOf(getNumbers().getFirstNum() + getNumbers().getSecondNum()));
            break;
            //button mvp
            case  R.id.div_button:
                presenter.getresultdiv();
                break;
                // button mvvm
            case  R.id.mul_button:
                architectureInterViewModel.Resultmulnum();
                break;
        }
    }
    //interfce mvp
    @Override
    public void onGetResultnum(double result) {
        divResultTextView.setText(String.valueOf( result));
    }
}
