package com.alyndroid.architecturepatternstutorialshomework.ui;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.alyndroid.architecturepatternstutorialshomework.pojo.NumberModel;
//viewModel mvvm
public class ArchitectureInterViewModel extends ViewModel {

  public   MutableLiveData<Integer> mutableLiveData = new MutableLiveData<>();
    public  void  Resultmulnum(){
        int Result = getNumbers().getFirstNum()*getNumbers().getSecondNum();
        mutableLiveData.setValue(Result);
    }
    public NumberModel getNumbers(){
        return new NumberModel(4, 2);
    }
}
