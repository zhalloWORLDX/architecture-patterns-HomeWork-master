package com.alyndroid.architecturepatternstutorialshomework.ui;
//interface mvp
public interface ArchitectureInterFace {
    void  onGetResultnum(double result);
}
