package com.alyndroid.architecturepatternstutorialshomework.ui;

import com.alyndroid.architecturepatternstutorialshomework.pojo.NumberModel;
//Presenter mvp
public class architecturePresenter {
    ArchitectureInterFace architectureInterFace;
    public architecturePresenter(ArchitectureInterFace architectureInterFace) {
        this.architectureInterFace = architectureInterFace;
    }

    public NumberModel getNumbers(){
        return new NumberModel(4, 2);
    }
    public void getresultdiv(){
        architectureInterFace.onGetResultnum(getNumbers().getFirstNum()/getNumbers().getSecondNum());
    }

}
